<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'sc3gesy0813_wpnYmQT' );

/** Database username */
define( 'DB_USER', 'sc3gesy0813_wpnYmQT' );

/** Database password */
define( 'DB_PASSWORD', 'z8QVsKPwhJzmOKh' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'R@lxh7o1dFg{[pJPo)9&13MTFbIp={}dVgXD^(y&d`h=Y65u/:Y)mjI~Y?:vzWF*' );
define( 'SECURE_AUTH_KEY',   'mnI9/;v4`Nvl@0rsoDoHZ(Ls`HHP%,5MI<@0U=9d-=t4kO!?`ht.S{vQ*2,W)g(_' );
define( 'LOGGED_IN_KEY',     's]_@&aV<zx1)=a<gz/Pq=3DV[+|2^ivlbuy 2!A1S2c;%Ptugfz]cLl4MYH(HY^A' );
define( 'NONCE_KEY',         'Xk$d4z37JJkI=s8lK5:Bso3%q{:29>5A/:Z`4;t#Dw 3xZ|e>4vYj.sru,pI@1ZU' );
define( 'AUTH_SALT',         'FKQQU{wO2Ah]v#T1pD+a%yYBch/]BE2.6j=tXU{>S%KP/8x4{Iy+bmd7APSN?Qi$' );
define( 'SECURE_AUTH_SALT',  '2hyv94!x&e.&PdEx]64OFAKU2~/Zce<,Nn|d9M}_Z[7A+e.W:M2Z,-;ul.Wlp:t!' );
define( 'LOGGED_IN_SALT',    '}:JZQ_cJkrSN88[&??XIB{G90V}z7Mrv$}|0 ap8^EU9}l}zFLUClRp)G44JFX/x' );
define( 'NONCE_SALT',        ':ndT%L0dKgLSOG/a_ 3mX7jB,(]1]r/eE7><4UP+yCNfyR}Rxf@b>M.Ub0AcMrh|' );
define( 'WP_CACHE_KEY_SALT', '1-;DW&7>mi1W1!f5@;=ne9XrMpNJ/h08#vi`T0}}S9,^cKT#C9k(>Au?7Lh;Ei,8' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define('WP_ALLOW_MULTISITE', true);

define( 'MULTISITE', true );
define( 'SUBDOMAIN_INSTALL', true );
define( 'DOMAIN_CURRENT_SITE', 'sc3gesy0813.universe.wf' );
define( 'PATH_CURRENT_SITE', '/' );
define( 'SITE_ID_CURRENT_SITE', 1 );
define( 'BLOG_ID_CURRENT_SITE', 1 );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
